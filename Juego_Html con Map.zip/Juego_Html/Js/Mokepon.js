//Deshabilitar las seccion de ataque
const sectionSeleccionarAtaque = document.getElementById('seleccionar-ataque')
//Deshabilitar las seccion de reiniciar
const sectionReiniciar = document.getElementById('reiniciar')
/** Se crea una variable luego se agrega el evento de getElementById y se le pasa el id del button */
const botonMascotaJugador = document.getElementById('boton-mascota')
//Hablitar el boton de reiniciar el juego- 
const botonReiniciar = document.getElementById('boton-reiniciar')
//Deshabilitar las seccion de seleccionarMascota
const sectionSeleccionarMascota = document.getElementById('seleccionar-mascota')
/** Este valor me devuelve un true u false document.getElementById('hipodoge').checked, 
 * checked significa que lo he seleccionado */
const spanMascotaJugador = document.getElementById('mascotaJugador')

const spanMascotaEnemigo = document.getElementById('mascotaEnemigo')

const spanVidasJugador = document.getElementById('vidasJugador')
const spanVidasEnemigo = document.getElementById('vidasEnemigo')

const sectionMensajes = document.getElementById('resultado')

const ataqueDelJugador = document.getElementById('ataque-Del-Jugador')
const ataqueDelEnemigo= document.getElementById('ataque-Del-Enemigo')
const contenedorTarjetas = document.getElementById('contenedorTarjetas')
const contenedorAtaques =document.getElementById('contenedorAtaques')
//Constantes para crear nuestro mapa
const sectionVerMapa = document.getElementById('ver-mapa')
const mapa = document.getElementById('mapa')

// Variables globales
let mokepones = []
let ataqueJugador = []
let ataqueEnemigo = []
let opcionDeMokepones
let inputHipodoge
let inputCapipepo
let inputRatigueya
let mascotaJugador
let mascotaJugadorObjeto
let ataquesMokepon
let ataquesMokeponEnemigo
//Habilitar los botones de ataque
let botonFuego 
let botonAgua 
let botonTierra
let botones = []
let indexAtaqueJugador
let indexAtaqueEnemigo
let victoriasJugador=0
let victoriasEnemigo=0
let vidasJugador = 3
let vidasEnemigo = 3 
let lienzo = mapa.getContext('2d')
let intervalo 
let mapaBackground = new Image()
mapaBackground.src = './assets/mokemap.webp'
let alturaQueBuscamos
let anchoDelMapa = window.innerWidth - 20 
const anchoMaximoDelMapa = 350 
if(anchoDelMapa > anchoMaximoDelMapa){
    anchoDelMapa = anchoMaximoDelMapa - 20 
}
alturaQueBuscamos = anchoDelMapa * 600 / 800
mapa.width = anchoDelMapa
mapa.height = alturaQueBuscamos

//Creación de la clase y su respectivo contructor 
class Mokepon {
    constructor(nombre, foto, vida, fotoMap) {
        this.nombre = nombre
        this.foto = foto
        this.vida = vida
        this.ataques = []
        this.ancho = 40
        this.alto = 40 
        this.x = aleatorio(0, mapa.width - this.ancho)
        this.y = aleatorio(0, mapa.height - this.alto)
        this.mapaFoto = new Image()
        this.mapaFoto.src = fotoMap
        this.velocidadX = 0
        this.velocidadY = 0 
        
    }

    pintarMokepon(){
        lienzo.drawImage(
            this.mapaFoto,
            this.x,
            this.y,
            this.ancho,
            this.alto
        )
    }
}
//Nuevos objetos de tipo Mokepon 

let hipodoge = new Mokepon('Hipodoge', './assets/mokepons_mokepon_hipodoge_attack.webp', 5, './assets/hipodoge.webp')
let capipepo = new Mokepon('Capipepo', './assets/mokepons_mokepon_capipepo_attack.webp', 5, './assets/capipepo.webp')
let ratigueya = new Mokepon('Ratigueya', './assets/mokepons_mokepon_ratigueya_attack.webp', 5, './assets/ratigueya.webp')

//Enemigos 
let hipodogeEnemigo = new Mokepon('Hipodoge', './assets/mokepons_mokepon_hipodoge_attack.webp', 5, './assets/hipodoge.webp')
let capipepoEnemigo = new Mokepon('Capipepo', './assets/mokepons_mokepon_capipepo_attack.webp', 5, './assets/capipepo.webp')
let ratigueyaEnemmigo = new Mokepon('Ratigueya', './assets/mokepons_mokepon_ratigueya_attack.webp', 5, './assets/ratigueya.webp')

hipodoge.ataques.push(
    {nombre:'🚿', id: 'boton-agua'},
    {nombre:'🚿', id: 'boton-agua'},
    {nombre:'🚿', id: 'boton-agua'},
    {nombre:'🔥', id: 'boton-fuego'},
    {nombre:'🌷', id: 'boton-tierra'}
)

hipodogeEnemigo.ataques.push(
    {nombre:'🚿', id: 'boton-agua'},
    {nombre:'🚿', id: 'boton-agua'},
    {nombre:'🚿', id: 'boton-agua'},
    {nombre:'🔥', id: 'boton-fuego'},
    {nombre:'🌷', id: 'boton-tierra'}
)

capipepo.ataques.push(
    {nombre:'🌷', id: 'boton-tierra'},
    {nombre:'🌷', id: 'boton-tierra'},
    {nombre:'🌷', id: 'boton-tierra'},
    {nombre:'🚿', id: 'boton-agua'},
    {nombre:'🔥', id: 'boton-fuego'}
    
)

capipepoEnemigo.ataques.push(
    {nombre:'🌷', id: 'boton-tierra'},
    {nombre:'🌷', id: 'boton-tierra'},
    {nombre:'🌷', id: 'boton-tierra'},
    {nombre:'🚿', id: 'boton-agua'},
    {nombre:'🔥', id: 'boton-fuego'}
    
)

ratigueya.ataques.push(
    {nombre:'🔥', id: 'boton-fuego'},
    {nombre:'🔥', id: 'boton-fuego'},
    {nombre:'🔥', id: 'boton-fuego'},
    {nombre:'🚿', id: 'boton-agua'},
    {nombre:'🌷', id: 'boton-tierra'}
)

ratigueyaEnemmigo.ataques.push(
    {nombre:'🔥', id: 'boton-fuego'},
    {nombre:'🔥', id: 'boton-fuego'},
    {nombre:'🔥', id: 'boton-fuego'},
    {nombre:'🚿', id: 'boton-agua'},
    {nombre:'🌷', id: 'boton-tierra'}
)


mokepones.push(hipodoge,capipepo,ratigueya)



function iniciarJuego(){
    //el metodo style display mostrar o no el documento. 
    sectionSeleccionarAtaque.style.display = 'none' //oculta la seccion
    //ocultar el mapa
    sectionVerMapa.style.display='none'
    //Método para recorrer el arreglo, por cada uno de los elemenos, haz algo. 
    mokepones.forEach((Mokepon)=>{
        opcionDeMokepones =`<input type="radio" name="mascota" id=${Mokepon.nombre} />
        <label class="tarjeta-de-makepon" for=${Mokepon.nombre}>
            <P>${Mokepon.nombre}</P>
            <img src=${Mokepon.foto} alt=${Mokepon.nombre} >
        </label>` 
        //imprime los elemenos de la variable
        contenedorTarjetas.innerHTML += opcionDeMokepones
        
        inputHipodoge = document.getElementById('Hipodoge')
        inputCapipepo = document.getElementById('Capipepo')
        inputRatigueya = document.getElementById('Ratigueya')

    })
    
    //el metodo style display mostrar o no el documento. 
    sectionReiniciar.style.display = 'none' //oculta la seccion
    /** a la variable boton--  utilizamos su metodo de addEventLis para que escucho el click  */
    botonMascotaJugador.addEventListener('click', seleccionarMascotaJugador)


    botonReiniciar.addEventListener('click', reiniarJuego)
}


function seleccionarMascotaJugador(){
     //el metodo style display  none no muestra el contenido. 
    sectionSeleccionarMascota.style.display = 'none' //oculta la seccion
     

    /** El metodo innerHTML sirve para cambiar los datos del spam en html */
    if(inputHipodoge.checked){
        spanMascotaJugador.innerHTML = inputHipodoge.id
        mascotaJugador = inputHipodoge.id
    }else if (inputCapipepo.checked){
        spanMascotaJugador.innerHTML = inputCapipepo.id
        mascotaJugador = inputCapipepo.id
    }else if (inputRatigueya.checked){
        spanMascotaJugador.innerHTML = inputRatigueya.id
        mascotaJugador = inputRatigueya.id
    }else{
        alert('Selecciona una mascota')
        location.reload()
    }

    extraerAtaque(mascotaJugador)
    //Inciar el mapa aqui luego de cargar los demás elementos 
    sectionVerMapa.style.display='flex'
    iniciarMapa()
}

function extraerAtaque(mascotaJugador){
    let ataques
    for (let i= 0; i< mokepones.length; i++) {
        if (mascotaJugador == mokepones[i].nombre ) {
            ataques = mokepones[i].ataques
        }  
    }
    mostrarAtaques(ataques)
}

function mostrarAtaques(ataques){
    ataques.forEach((ataque)=>{
        ataquesMokepon = 
        `<button id=${ataque.id} class="boton-de-ataque BAtaque">${ataque.nombre}</button>`
        contenedorAtaques.innerHTML += ataquesMokepon
    })
    //Habilitar los botones de ataque
    botonFuego = document.getElementById('boton-fuego')
    botonAgua  = document.getElementById('boton-agua')
    botonTierra = document.getElementById('boton-tierra')

    //Selecciona todos los elementos del mismo tipo 
    botones = document.querySelectorAll('.BAtaque')
}

function secuenciaAtaque(){
    botones.forEach((boton)=>{
        boton.addEventListener('click', (e)=> {
            if (e.target.textContent == '🔥') {
                ataqueJugador.push('FUEGO')
                console.log(ataqueJugador)
                boton.style.background = '#112f58'
                boton.disabled = true 
            } else if(e.target.textContent == '🚿'){
                ataqueJugador.push('AGUA')
                console.log(ataqueJugador)
                boton.style.background = '#112f58'
                boton.disabled = true 
            }else{
                ataqueJugador.push('TIERRA')
                console.log(ataqueJugador)
                boton.style.background = '#112f58'
                boton.disabled = true 
            }
            ataqueAleatorioEnemigo()
        })
    })
    
}


function seleccionarMascotaEnemigo(enemigo){
    //Agregamos el tamaño del arreglo 
    //let mascotaAleatorio = aleatorio(0, mokepones.length-1)
    //Traer el ataque del enemigo 
    //ataquesMokeponEnemigo = mokepones[mascotaAleatorio].ataques
    //Nos muestra el nombre del objeto elegido al azar 
    //spanMascotaEnemigo.innerHTML = mokepones[mascotaAleatorio].nombre
    spanMascotaEnemigo.innerHTML=enemigo.nombre
    ataquesMokeponEnemigo=enemigo.ataques
    secuenciaAtaque()
}


function ataqueAleatorioEnemigo(){
    let ataqueAleatorio = aleatorio(0 , mokepones.length-1)

    if(ataqueAleatorio == 0 || ataqueAleatorio == 1){
        ataqueEnemigo.push('FUEGO')
    }else if (ataqueAleatorio == 3 || ataqueAleatorio == 4){
        ataqueEnemigo.push('AGUA')
    }else{
        ataqueEnemigo.push('TIERRA')
    }

    iniciarPelea()
}

//Imprime los ataques hasta que se realicen los 5 ataques. 
function iniciarPelea(){
    if (ataqueJugador.length === 5) {
        combate()
    }
}

function indexAmbosOponentes(jugador, enemigo){
    indexAtaqueJugador = ataqueJugador[jugador]
    indexAtaqueEnemigo = ataqueEnemigo[enemigo]
}

function combate(){
    
    for (let index = 0; index < ataqueJugador.length; index++) {
        if (ataqueJugador[index] === ataqueEnemigo[index]) {
            indexAmbosOponentes(index, index)
            crearMensaje('EMPATE')
        }else if(ataqueJugador[index] === 'FUEGO' && ataqueEnemigo[index] === 'TIERRA'){
            indexAmbosOponentes(index, index)
            crearMensaje('GANASTES')
            victoriasJugador++
            spanVidasJugador.innerHTML = victoriasJugador
        }else if(ataqueJugador[index] === 'AGUA' && ataqueEnemigo[index]==='FUEGO'){
            indexAmbosOponentes(index, index)
            crearMensaje('GANASTES')
            victoriasJugador++
            spanVidasJugador.innerHTML = victoriasJugador
        }else if(ataqueJugador[index] === 'TIERRA' && ataqueDelEnemigo[index]=== 'AGUA'){
            indexAmbosOponentes(index, index)
            crearMensaje('GANASTES')
            victoriasJugador++
            spanVidasJugador.innerHTML = victoriasJugador
        }else{
            indexAmbosOponentes(index, index)
            crearMensaje('PERDISTES')
            victoriasEnemigo++
            spanVidasEnemigo.innerHTML = victoriasEnemigo
        }
        
    }
    revisarVidas()
}

function revisarVidas(){
    if(victoriasJugador === victoriasEnemigo){
        crearMensajeFinal("Esto fue un empate")
    }else if(victoriasJugador > victoriasEnemigo){
        crearMensajeFinal("Felicitaciones! Ganastes 🥳")
    }else{
        crearMensajeFinal('Lo siento, perdistes 😓 ')
    }
}

function crearMensajeFinal(resultadoFinal){
    /** metodo createElement crear un nuevo parrafo  */
    //let parrafo = document.createElement('p')
    sectionMensajes.innerHTML = resultadoFinal
    /**El método appendChild agrega el parrafo modificado en el metodo anterior */
    //sectionMensajes.appendChild(parrafo)

    //el metodo style display mostrar o no el documento. 
    sectionReiniciar.style.display = 'block' //oculta la seccion
        
}

function crearMensaje(resultado){
    /** metodo createElement buscar informacion  */
    let nuevoAtaqueDelJugador = document.createElement('p')
    let nuevoAtaqueDelEnemigo = document.createElement('p')

    sectionMensajes.innerHTML= resultado
    nuevoAtaqueDelJugador.innerHTML = indexAtaqueJugador
    nuevoAtaqueDelEnemigo.innerHTML = indexAtaqueEnemigo
    /**El método appendChild agrega el parrafo modificado en el metodo anterior */
    ataqueDelJugador.appendChild(nuevoAtaqueDelJugador)
    ataqueDelEnemigo.appendChild(nuevoAtaqueDelEnemigo)
}


function reiniarJuego(){
    //location.reload() reinicia el juego :) 
    location.reload()
}

// Codigo que hace uso de Canva 

function pintarCanvas(){

    mascotaJugadorObjeto.x = mascotaJugadorObjeto.x + mascotaJugadorObjeto.velocidadX
    mascotaJugadorObjeto.y = mascotaJugadorObjeto.y + mascotaJugadorObjeto.velocidadY
    //limpia el canva 
    lienzo.clearRect(0, 0, mapa.clientWidth, mapa.height)
    lienzo.drawImage(
        mapaBackground,
        0,
        0,
        mapa.width,
        mapa.height
    )

    mascotaJugadorObjeto.pintarMokepon()
    hipodogeEnemigo.pintarMokepon()
    capipepoEnemigo.pintarMokepon()
    ratigueyaEnemmigo.pintarMokepon()
    //Para la colision de los enemigos-
    if(mascotaJugadorObjeto.velocidadX !==0 || mascotaJugadorObjeto.velocidadY !==0 ){
        revisarColision(hipodogeEnemigo)
        revisarColision(capipepoEnemigo)
        revisarColision(ratigueyaEnemmigo)
    }

}

function moverDerecha(){
    mascotaJugadorObjeto.velocidadX = 5
}

function moverIzquierda(){
    mascotaJugadorObjeto.velocidadX = -5
}

function moverAbajo(){
    mascotaJugadorObjeto.velocidadY = 5
}

function moverArriba(){
    mascotaJugadorObjeto.velocidadY = -5
}

function detenerMovimiento(){
    mascotaJugadorObjeto.velocidadX = 0
    mascotaJugadorObjeto.velocidadY = 0 
}

function sePresionaUnaTecla(event){
    //Muestra la tecla que se este presionando. 
    //console.log(event.key)
    switch (event.key) {
        case 'ArrowUp':
            moverArriba()
            break;
        case 'ArrowDown':
            moverAbajo()
            break;
        case 'ArrowLeft':
            moverIzquierda()
            break;
        case 'ArrowRight':
            moverDerecha()
            break;
        default:
            break;
    }
}

function iniciarMapa(){
    mascotaJugadorObjeto = obtenerObjetoMascota(mascotaJugador)
    //la función recibe el nombre de la función y luego recibe el miles segundos en cuanto va a dar la función 
    intervalo = setInterval(pintarCanvas, 50)
    //Función para presionar una tecla
    window.addEventListener('keydown', sePresionaUnaTecla)
     //evento cuando se suelte la tecla 
    window.addEventListener('keyup', detenerMovimiento)
}

function obtenerObjetoMascota(){
    for (let i= 0; i< mokepones.length; i++) {
        if (mascotaJugador == mokepones[i].nombre ) {
            return mokepones[i]
        }  
    }
}
//comprobar si las imagenes colisionan en un punto 
function revisarColision(enemigo){
    const arribaEnemigo = enemigo.y
    const abajoEnemigo = enemigo.y + enemigo.alto
    const derechaEnemigo = enemigo.x + enemigo.ancho
    const izquierdaEnemigo = enemigo.x 

    //Mascota 
    const arribaMascota = mascotaJugadorObjeto.y
    const abajoMascota = mascotaJugadorObjeto.y + mascotaJugadorObjeto.alto
    const derechaMascota= mascotaJugadorObjeto.x + mascotaJugadorObjeto.ancho
    const izquierdaMascota = mascotaJugadorObjeto.x

    if(
        abajoMascota < arribaEnemigo || 
        arribaMascota > abajoEnemigo ||
        derechaMascota < izquierdaEnemigo ||
        izquierdaMascota > derechaEnemigo
    ){
        return; 
    }
    detenerMovimiento()
    //Detiene el ciclo en que se ejecuta la funcion 
    clearInterval(intervalo)
    //el metodo style display block muestra el contenido. 
    sectionSeleccionarAtaque.style.display = 'flex' //block mostrar la seccion
    //Ocultamos el mapa
    sectionVerMapa.style.display='none'
    //Selecciona la mascota con quien vamos a luchar
    seleccionarMascotaEnemigo(enemigo)
}


//Fin del codigo de canva 

/** funcion de sacar numeros aleatorios entre un rango dado  */
function aleatorio(min, max ){
    return Math.floor(Math.random()*(max - min +1)+min )
}

/** Este código le indica que lea el navegador, crear nueva función cargarJuego */
window.addEventListener('load', iniciarJuego )

//me quede en el 69




